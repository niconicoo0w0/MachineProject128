#include "elevation_dataset.hpp"

int main() {
    ElevationDataset e = ElevationDataset("/home/vagrant/src/mp-mountain-paths-niconicoo0w0/example-data/ex_input_data/all-tie-row1-2w-3h.dat", 2, 3);
    // ElevationDataset e = ElevationDataset("/home/vagrant/src/mp-mountain-paths-niconicoo0w0/example-data/ex_input_data/all-tie-row1-2w-3h.dat", 2, 3);
}