#include "path_image.hpp"
#include "grayscale_image.hpp"
#include "elevation_dataset.hpp"
#include "path.hpp"
#include <vector>
#include <string>
#include "color.hpp"
#include <iostream>
#include <fstream>

#define TFFSS 3567891

size_t up_ele = 0;
size_t down_ele = 0;
size_t forward_ele = 0;

const int kOner= 252;
const int kTwor= 25;
const int kThreer= 63;
const int kOneg= 31;
const int kTwog= 253;
const int kThreeg= 13;

Color red = Color(kOner, kTwor, kThreer);
// Color green = Color(kOneg, kTwog, kThreeg);

int PathImage::Compare(size_t forward_ele, size_t up_ele, size_t down_ele, Path path) {
    if (forward_ele == down_ele && forward_ele == up_ele && up_ele == down_ele) { //三个都相等
        path.IncEleChange(forward_ele);
        return 0;
    }
    if (up_ele == down_ele) { //上下相等
        path.IncEleChange(down_ele);
        return -1;
    }
    if (forward_ele == up_ele || forward_ele == down_ele) { //上中或者上下相等
        path.IncEleChange(forward_ele);
        return 0;
    }
    if (forward_ele < down_ele && forward_ele < up_ele) { 
        path.IncEleChange(forward_ele);
        return 0;
    }
    if (down_ele < forward_ele && down_ele < up_ele) {
        path.IncEleChange(down_ele);
        return -1;
    } 
    if (up_ele < forward_ele && up_ele < down_ele) {
        path.IncEleChange(up_ele);
        return 1;
    }
    return 0;
}

unsigned int min = TFFSS;
unsigned int min_index = 0;

PathImage::PathImage(const GrayscaleImage &image, const ElevationDataset &dataset): width_(image.Width()), height_(image.Height()) {
    path_image_ = image.GetImage();
    for (size_t i = 0; i < height_; i++) {
        size_t next_step = i;
        Path p(width_, i);
        for (size_t col = 0; col < width_ - 1; col++) {
            p.SetLoc(col, next_step);
            path_image_[next_step][col] = red;
            if (next_step == 0) {
                forward_ele = abs(dataset.DatumAt(next_step, col + 1) - dataset.DatumAt(next_step, col));
                down_ele = abs(dataset.DatumAt(next_step + 1, col + 1) - dataset.DatumAt(next_step, col));
                next_step += Compare(forward_ele, SIZE_MAX, down_ele, p);
                p.SetLoc(col, next_step);
                path_image_[next_step][col] = red;
            } else if (next_step == height_ - 1) {
                forward_ele = abs(dataset.DatumAt(next_step, col + 1) - dataset.DatumAt(next_step, col));
                up_ele = abs(dataset.DatumAt(next_step - 1, col + 1) - dataset.DatumAt(next_step, col));
                next_step += Compare(forward_ele, up_ele, SIZE_MAX, p);
                p.SetLoc(col, next_step);
                path_image_[next_step][col] = red;
            } else {
                forward_ele = abs(dataset.DatumAt(next_step, col + 1) - dataset.DatumAt(next_step, col));
                up_ele = abs(dataset.DatumAt(next_step - 1, col + 1) - dataset.DatumAt(next_step, col));
                down_ele = abs(dataset.DatumAt(next_step + 1, col + 1) - dataset.DatumAt(next_step, col));
                next_step += Compare(forward_ele, up_ele, down_ele, p);
                p.SetLoc(col, next_step);
                path_image_[next_step][col] = red;
            }
            paths_.push_back(p);
            if (p.EleChange() < min) {
                min = p.EleChange();
                min_index = i;
            }
        }
        std::vector<size_t> green = paths_[min_index].GetPath();
        for (size_t col = 0; col < image.Width(); col++) { path_image_[min_index][col] = Color(kOneg, kTwog, kThreeg);}
    }
}



size_t PathImage::Width() const {
    return width_;
}

size_t PathImage::Height() const {
    return height_;
}

unsigned int PathImage::MaxColorValue() const {
    return PathImage::kMaxColorValue;
}

const std::vector<Path>& PathImage::Paths() const {
    return paths_;
}

const std::vector<std::vector<Color> >& PathImage::GetPathImage() const {
    return path_image_;
}

void PathImage::ToPpm(const std::string& name) const {
    std::ofstream o;
    o.open(name);
    o << "P3" << std::endl;
    o << width_ << " " << height_ << std::endl;
    o << "255" << std::endl;
    for (size_t row = 0; row < height_; row++) {
        for (size_t col = 0; col < width_; col++) {
            o << path_image_[row][col].Red() << ' ' << path_image_[row][col].Green() << ' ' << path_image_[row][col].Blue();
            if (height_ - 1 != 1) {
                o << '\n';
            }
        }
        o << std::endl;
    }
    o.close();
}	