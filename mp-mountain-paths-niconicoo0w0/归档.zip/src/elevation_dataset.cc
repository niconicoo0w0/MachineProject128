#include "elevation_dataset.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

//Initializes the primitive data members with their respective values as read from the file; 
//populates the two-dimensional std::vector<std::vector<int>> with elevation data from file. 
//Sets width_ and height_ appropriately. 
//Records max_ele_ and min_ele_ observed.

// void printVector(std::vector<std::vector<int> > &v)
// {
//     std::vector<std::vector<int> >::iterator iter;
//     for (iter = v.begin(); iter != v.end() ; ++iter) {
//         for (size_t i = 0; i < (*iter).size(); ++i) {
//             std::cout << (*iter)[i] << " ";
//         }
//         std::cout << std::endl;
//     }
// }



ElevationDataset::ElevationDataset(const std::string& filename, size_t width, size_t height) {
    width_ = width;
    height_ = height;
    std::ifstream file{filename};
    if (!file.is_open()) { throw std::runtime_error("can not open file"); }
    std::vector<std::vector<int>> result; //same as data_
    int values = 0;
    size_t s = 0;
    std::vector<int> subvector; //use to check the size
    while (file >> values) {
        subvector.push_back(values);
    }
    if (subvector.size() != width_ * height_) {  //check for input size
        throw std::runtime_error("incorrect size");  
    }
    for (size_t row = 0; row < height_; row++) {
        std::vector<int> temp;
        for (size_t col = 0; col < width_; col++) {
            temp.push_back(subvector[s]);
            s += 1;
        }
        result.push_back(temp);
    }
    data_ = result;
    max_ele_ = data_[0][0];
    min_ele_ = data_[0][0];
    for (size_t row = 0; row < data_.size(); row++) {
        for (size_t col = 0; col < data_[0].size(); col++) {
            if (data_[row][col] > max_ele_) { max_ele_ = data_[row][col]; }
            if (data_[row][col] < min_ele_) { min_ele_ = data_[row][col]; }
        }
    }
}

size_t ElevationDataset::Width() const {
    return width_;
}
size_t ElevationDataset::Height() const {
    return height_;
}
int ElevationDataset::MaxEle() const {
    return max_ele_;
}
int ElevationDataset::MinEle() const {
    return min_ele_;
}
int ElevationDataset::DatumAt(size_t row, size_t col) const {
    return data_[row][col];
}
const std::vector<std::vector<int> >& ElevationDataset::GetData() const {
    return data_;
}